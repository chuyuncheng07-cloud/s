history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
sed -i 's|/var/disco10gb.img|#var/disco10gb.img|g' /etc/fstab
reboot
