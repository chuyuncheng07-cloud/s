#!/bin/bash
if test "$1" = "-h" -o "$1" = "--help"; then
     echo "Uso: $0 (origen)(destino)"
     echo "Ejemplo; $0 /var/logs /backup_dir"
     exit 0
fi
ORIGEN=$1
DESTINO=$2
if test -z "$ORIGEN" -o -z "$DESTINO"; then
     echo "Error: Debe indicar origen y destino."
     exit 1
fi 
if test ! -d "$ORIGEN" -o ! -d "$DESTINO"; then
     echo "Error: El origen o el destino no existen o no son directorios."
     exit 1
fi
FECHA=$(date +%Y%m%d)
NOMBRE_BASE=$(basename "$ORIGEN")
tar -czf "$DESTINO/$NOMBRE_BASE_$FECHA.tar.gz" "$ORIGEN"
echo "Backup completado exitosamente en $DESTINO"
